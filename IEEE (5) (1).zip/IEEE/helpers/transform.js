const { DESTRUCTION } = require("dns");

function addZero(x,n){

while(x.toString().length< n)
{
    x='0'+x;
}
return x;

}
exports.transform=()=>{

    days=new Date();
    console.log(days);

    years= new Date().getFullYear();
    month= new Date().getMonth();
    hours= addZero(days.getHours(),2);
    mins= addZero(days.getMinutes(),2);
    seconds= addZero(days.getSeconds(),2);
    mseconds= addZero(days.getMilliseconds(),3);



    return (`${years}${month}${days.getDate()}${hours}${mins}${seconds}${mseconds}${parseInt(Math.random() *10000 )}`);


}