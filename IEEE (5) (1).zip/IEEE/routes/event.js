const express = require("express");
const userRouter = express.Router();

const eventcontroller = require("../Controller/eventcontroller");
const multer = require("multer");
const middleware = require("../middelwares/auth");
const trans = require("../helpers/transform");

const mystorage = multer.diskStorage({
  destination: (request, file, next) => {
    console.log("file::", file);

    next(null, "./eventuploads/");
  },
  filename: (request, file, next) => {
    const filename = trans.transform() + "-" + file.originalname;
    next(null, file.originalname);
  },
});

const myFileFilter = (request, file, next) => {
  if (file.mimetype === "image/jpeg" || file.mimetype === "image/png") {
    next(null, true);
  } else {
    next(null, false);
  }
};

const upload = multer({
  storage: mystorage,
  limits: {
    fileSize: 1024 * 1024 * 5,
  },
  fileFilter: myFileFilter,
}); //files will be saved on file uploads

userRouter.get("/:eventid", eventcontroller.select);
userRouter.post("/",middleware.checkAuth, upload.single("eventImage"), eventcontroller.create);
userRouter.put("/:eventid", middleware.checkAuth,eventcontroller.update);
userRouter.delete("/:eventid",middleware.checkAuth, eventcontroller.deletee);

module.exports = userRouter;
