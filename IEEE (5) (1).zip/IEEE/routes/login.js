const express = require("express");
const userRouter = express.Router();
const login=require("../Controller/login");


userRouter.post("/", login.login);

 
module.exports=userRouter;