const joi = require('joi')

exports.isValid = (username,password)=>{
    adminSchema = joi.object({
        username:joi.string().min(3).max(45).required(),
        
        password:joi.string().min(3).max(20).required()
    })

    const adminValidationResult =  adminSchema.validate({username,password })

    if (adminValidationResult.error) {
        return false
    }
    return true

}