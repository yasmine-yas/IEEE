const databaseConfig = require('../db/config/database-connection')
const knex = databaseConfig.connect()

exports.selectOne = async (username)=>{
    const admin =  await knex('admin')
    .select(['username'])
    .where({
        username:username,
    })
    .limit(1)

    return admin
}

exports.add = async (username)=>{

    const admin =  await knex('admin')
    .insert({
       username,
       
    })

    return admin

}
