const databaseConfig = require('../db/config/database-connection')
const knex = databaseConfig.connect()

exports.selectOne = async (username)=>{
    const user =  await knex('admin')
    .select(['username','password'])
    .where({
        username:username,
    })
    .limit(1)

    return user
}

exports.add = async (username,password)=>{

    const user =  await knex('admin')
    .insert({
       username,
       password
    })

    return user

}