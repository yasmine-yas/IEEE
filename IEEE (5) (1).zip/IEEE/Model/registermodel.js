const databaseConfig = require('../db/config/database-connection')
const knex = databaseConfig.connect()

exports.selectOne = async (register_id)=>{
    const user =  await knex('register')
    .select(['register_id'])
    .where({
        register_id:register_id,
    })
    .limit(1)

    return user
}

exports.add = async (register_id)=>{

    const user =  await knex('register')
    .insert({
       register_id,
       
    })

    return user

}