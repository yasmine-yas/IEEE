const joi=require("joi");
const adminModel = require('../Model/eventmodel')
const multer = require('multer');
const upload=multer({dest:'eventuploads/'}) //files will be saved on file uploads






const knex = require('knex')({
    client: 'mysql',
    connection: {
      host : '127.0.0.1',
      port : 3306,
      user : 'root',
      password : '123456',
      database : 'ieee_db'
    }
  });
 




  
const select=(request,response)=>{
    const eventid=request.params.eventid;
knex("event").select(["label","paragraph","eventid"]).where({
    eventid:eventid,
})
.then((event)=>{response.status(200).json(event);})
.catch((error)=>{console.log(error);})

};

const create=(request,response)=>{
const eventid=request.body.eventid;
const label=request.body.label;
const paragraph=request.body.paragraph;
const{filename,path,mimetype}=request.file;





const uservalidate=joi.object(
    {
eventid:joi.number().min(1),
label:joi.string().min(2).required(),
paragraph:joi.string().min(2).required(),

    }
)
const result=uservalidate.validate({eventid,label,paragraph});
if(result.error)
{
    console.log(result.error);
    return response.status(400).json("invalid data")
}
else{

  
exports.eventcontroller = async (request,response)=>{
     
    const {eventid} = request.body

    const admin = await signupmodel.selectOne(eventid)

    if (admin[0] == null) {
        return response.status(400).json("Invalid event id")
    }
    }
knex("event").insert(
{
eventid:eventid,
label:label,
paragraph:paragraph,
file_name:filename,
file_path:path,
mime_type:mimetype,



}).then((event)=>
{
response.status(201).json(" event has created successfully");
})
.catch((error)=>{
    response.status(201).json("check your data");
});


};

}

const update=(request,response)=>{
const eventid=request.params.eventid;
const label=request.body.label;
const paragraph=request.body.paragraph;


    knex("event").update({

        eventid:eventid,
        label:label,
        paragraph:paragraph,
        
        
    }).where({
        eventid:eventid,
    }).then((event) =>
    {
        response.status(201).json("event has been updated");

    })
    .catch((error)=>{
        console.log(error);
        });

};

const deletee=(request,response)=>{

const eventid=request.params.eventid;
knex("event")
.delete()
.where({

    eventid:eventid,
}).then((event) =>
{
    response.status(201).json("event has been deleted");

})
.catch((error)=>{
    console.log(error);
    });

}



exports.selectOne = async (eventid)=>{
    const admin =  await knex('event')
    .select(['label','paragraph'])
    .where({
        eventid:eventid
    })
    .limit(1)

    return admin
}




module.exports={
    select,
    create,
    update,
    deletee,
};