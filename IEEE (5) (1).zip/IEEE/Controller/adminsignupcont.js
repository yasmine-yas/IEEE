const joi = require("joi");
const bcrypt = require("bcrypt");
const adminValidation = require("../validations/admin");
const signupModel = require("../Model/adminsignupModel");
const jwt = require("jsonwebtoken");


const knex = require("knex")({
  client: "mysql",
  connection: {
    host: "127.0.0.1",
    port: 3306,
    user: "root",
    password: "123456",
    database: "ieee_db",
  },
});


const select = (request, response) => {
    knex("admin").select(["admin_id","username","password"])
    .then((admin)=>{response.status(200).json(admin);})
    .catch((error)=>{console.log(error);})

   
};

const create = async (request, response) => {
  const admin_id = request.body.admin_id;
  const username = request.body.username;
  const password = request.body.password;

  const salt = bcrypt.genSaltSync(10);
  const hashpassword = bcrypt.hashSync(password, salt);

  const adminvalidate = joi.object({
    admin_id: joi.number().min(1).required(),
    
    username: joi.string().min(3).required(),
    
    password: joi.string().min(3).max(25).required(),
  });
  const result = adminvalidate.validate({
    admin_id,
    username,
    password,
  });
  if (result.error) {
    console.log(result.error);
    return response.status(400).json("invalid data");
  } else {

    // check on username

    const admin = await signupModel.selectOne(username)

    if (admin[0] != null) {
      return response.status(400).json("invalid username")
    }
   
    
    knex("admin")
      .insert({
        admin_id: admin_id,
        username: username,
        password: hashpassword,
      })
      .then((admin) => {
        response.status(201).json(username + " you've signed up successfully");
      })
      .catch((error) => {
        response.status(201).json("this id already exists");
      });
  }
};

const update = (request, response) => {
  const admin_id = request.body.admin_id;

  const username = request.body.username;
  

  const password = request.body.password;

  knex("admin")
    .update({
        admin_id: admin_id,
        username: username,
        password: hashpassword,
    })
    .where({
        admin_id: admin_id,
    })
    .then((admin) => {
      response.status(201).json("your data has been updated");
    })
    .catch((error) => {
      console.log(error);
    });
};

const deletee = (request, response) => {
  const admin_id = request.params.admin_id;
  knex("admin")
    .delete()
    .where({
      admin_id: admin_id,
    })
    .then((admin) => {
      response.status(201).json("your account have been deleted");
    })
    .catch((error) => {
      console.log(error);
    });
};

exports.selectOne = async (username) => {
  const admin = await knex("admin")
    .select(["username", "password"])
    .where({
      username: username,
    })
    .limit(1);

  return admin;
};

module.exports = {
  select,
  create,
  update,
  deletee,
};
