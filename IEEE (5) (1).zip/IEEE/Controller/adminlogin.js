
const adminValidation = require("../validations/admin")
const adminModel = require('../Model/adminloginmodel')
const loginValidation = require("../validations/login")
const bcrypt = require('bcrypt')
const jwt = require("jsonwebtoken")


exports.login = async (request,response)=>{
     
    const {username,password} = request.body

    const isLoginValid = loginValidation.isValid(username,password)


    if (!isLoginValid) {
       
        return response.status(400).json("Invalid Data")
    }


   
    const admin = await adminModel.selectOne(username)

    if (admin[0] == null) {
       
        return response.status(400).json("Invalid username or password")
    }


    const isPasswordCorrect =  bcrypt.compareSync(password,admin[0].password)

    if (isPasswordCorrect) {

        jwt.sign({
            username:username,
            userType:'user'
        },'123456',{},(error,token)=>{

            return response.status(200).json({
                msg:'Success',
                token:token
            })

        })

    }else {
        return response.status(400).json("Invalid password")

    }


}